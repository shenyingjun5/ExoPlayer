/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.android.exoplayer2.source.rtsp;

/** Listener for RTCP feedback request lifecycle events. */
public interface RtspFeedbackListener {

  /** Called when a key-frame feedback request is accepted by policy and queued for sending. */
  default void onRtcpFeedbackRequested(RtcpFeedbackRequest request) {}

  /** Called when a key-frame feedback request is blocked by policy. */
  default void onRtcpFeedbackThrottled(RtcpFeedbackRequest request) {}

  /** Called when a key-frame feedback request has been sent. */
  default void onRtcpFeedbackSent(RtcpFeedbackRequest request) {}

  /** Called when a key-frame feedback request failed to send. */
  default void onRtcpFeedbackSendFailed(RtcpFeedbackRequest request, Exception error) {}
}

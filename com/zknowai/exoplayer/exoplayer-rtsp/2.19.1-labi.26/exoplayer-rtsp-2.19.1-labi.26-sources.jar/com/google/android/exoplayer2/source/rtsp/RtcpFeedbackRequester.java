/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.android.exoplayer2.source.rtsp;

/** Requests RTCP feedback from RTP processing code. */
public interface RtcpFeedbackRequester {

  /** Requests a key frame. */
  boolean requestKeyFrame(@RtcpFeedbackReason.Reason int reason);

  /** Requests one RTCP Generic NACK packet for a bounded RTP sequence range. */
  default boolean requestGenericNack(int mediaSsrc, int pid, int blp) {
    return false;
  }
}

/*
 * Copyright 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.android.exoplayer2.source.rtsp;

import static com.google.android.exoplayer2.util.Assertions.checkNotNull;

import android.os.Handler;
import androidx.annotation.Nullable;
import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.extractor.DefaultExtractorInput;
import com.google.android.exoplayer2.extractor.Extractor;
import com.google.android.exoplayer2.extractor.ExtractorOutput;
import com.google.android.exoplayer2.extractor.PositionHolder;
import com.google.android.exoplayer2.upstream.DataSourceUtil;
import com.google.android.exoplayer2.upstream.Loader;
import com.google.android.exoplayer2.util.ConditionVariable;
import com.google.android.exoplayer2.util.Util;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import org.checkerframework.checker.nullness.qual.MonotonicNonNull;

/**
 * A {@link Loader.Loadable} that uses two {@link RtpDataChannel} instances to listen on incoming
 * RTP and RTCP packets.
 *
 * <ul>
 *   <li>When using UDP as RTP transport, the local RTP UDP port number is selected by the runtime
 *       on opening the first {@link RtpDataChannel}; the second {@link RtpDataChannel} for RTCP
 *       uses the port number that is the RTP UDP port number plus one.
 *   <li>When using TCP as RTP transport, the first {@link RtpDataChannel} for RTP uses the {@link
 *       #trackId} as its interleaved channel number; the second {@link RtpDataChannel} for RTCP
 *       uses the interleaved channel number that is the RTP interleaved channel number plus one.
 * </ul>
 *
 * <p>Pass a listener via the constructor to receive a callback when the RTSP transport is ready.
 * {@link #load} will throw an {@link IOException} if either of the two data channels fails to open.
 *
 * <p>Received RTP packets' payloads will be extracted by an {@link RtpExtractor}, and will be
 * written to the {@link ExtractorOutput} instance provided at construction.
 *
 * @deprecated com.google.android.exoplayer2 is deprecated. Please migrate to androidx.media3 (which
 *     contains the same ExoPlayer code). See <a
 *     href="https://developer.android.com/guide/topics/media/media3/getting-started/migration-guide">the
 *     migration guide</a> for more details, including a script to help with the migration.
 */
@Deprecated
/* package */ final class RtpDataLoadable implements Loader.Loadable {

  /** Called on loadable events. */
  public interface EventListener {
    /**
     * Called when the transport information for receiving incoming RTP and RTCP packets is ready.
     *
     * @param transport The RTSP transport (RFC2326 Section 12.39) including the client data port
     *     and RTCP port.
     * @param rtpDataChannel The {@link RtpDataChannel} associated with the transport.
     */
    void onTransportReady(String transport, RtpDataChannel rtpDataChannel);
  }

  /** The track ID associated with the Loadable. */
  public final int trackId;
  /** The {@link RtspMediaTrack} to load. */
  public final RtspMediaTrack rtspMediaTrack;

  private final EventListener eventListener;
  private final ExtractorOutput output;
  private final Handler playbackThreadHandler;
  private final RtpDataChannel.Factory rtpDataChannelFactory;
  @Nullable private final RtspDiagnosticsListener rtspDiagnosticsListener;
  @Nullable private final RtcpFeedbackRequester rtcpFeedbackRequester;
  private final RtcpFeedbackPolicy rtcpFeedbackPolicy;
  private final RtspBacklogRecoveryPolicy rtspBacklogRecoveryPolicy;
  private final boolean rtspPacketDiagnosticsEnabled;
  private final ConditionVariable playbackTimingReady = new ConditionVariable();

  @Nullable private RtpDataChannel dataChannel;
  private @MonotonicNonNull RtpExtractor extractor;
  private @MonotonicNonNull DefaultExtractorInput extractorInput;

  private volatile boolean loadCancelled;
  private volatile long pendingSeekPositionUs;
  private volatile long nextRtpTimestamp;

  /**
   * Creates an {@link RtpDataLoadable} that listens on incoming RTP traffic.
   *
   * <p>Caller of this constructor must be on playback thread.
   *
   * @param trackId The track ID associated with the Loadable.
   * @param rtspMediaTrack The {@link RtspMediaTrack} to load.
   * @param eventListener The {@link EventListener}.
   * @param output A {@link ExtractorOutput} instance to which the received and extracted data will
   * @param rtpDataChannelFactory A {@link RtpDataChannel.Factory} for {@link RtpDataChannel}.
   */
  public RtpDataLoadable(
      int trackId,
      RtspMediaTrack rtspMediaTrack,
      EventListener eventListener,
      ExtractorOutput output,
      RtpDataChannel.Factory rtpDataChannelFactory) {
    this(
        trackId,
        rtspMediaTrack,
        eventListener,
        output,
        rtpDataChannelFactory,
        /* rtspDiagnosticsListener= */ null,
        /* rtcpFeedbackRequester= */ null,
        RtcpFeedbackPolicy.DEFAULT,
        RtspBacklogRecoveryPolicy.DISABLED,
        /* rtspPacketDiagnosticsEnabled= */ false);
  }

  public RtpDataLoadable(
      int trackId,
      RtspMediaTrack rtspMediaTrack,
      EventListener eventListener,
      ExtractorOutput output,
      RtpDataChannel.Factory rtpDataChannelFactory,
      @Nullable RtspDiagnosticsListener rtspDiagnosticsListener,
      @Nullable RtcpFeedbackRequester rtcpFeedbackRequester,
      RtcpFeedbackPolicy rtcpFeedbackPolicy,
      RtspBacklogRecoveryPolicy rtspBacklogRecoveryPolicy,
      boolean rtspPacketDiagnosticsEnabled) {
    this.trackId = trackId;
    this.rtspMediaTrack = rtspMediaTrack;
    this.eventListener = eventListener;
    this.output = output;
    this.playbackThreadHandler = Util.createHandlerForCurrentLooper();
    this.rtpDataChannelFactory = rtpDataChannelFactory;
    this.rtspDiagnosticsListener = rtspDiagnosticsListener;
    this.rtcpFeedbackRequester = rtcpFeedbackRequester;
    this.rtcpFeedbackPolicy = rtcpFeedbackPolicy;
    this.rtspBacklogRecoveryPolicy = rtspBacklogRecoveryPolicy;
    this.rtspPacketDiagnosticsEnabled = rtspPacketDiagnosticsEnabled;
    pendingSeekPositionUs = C.TIME_UNSET;
  }

  /**
   * Sets the timestamp of an RTP packet to arrive.
   *
   * @param timestamp The timestamp of the RTP packet to arrive. Supply {@link C#TIME_UNSET} if its
   *     unavailable.
   */
  public void setTimestamp(long timestamp) {
    if (timestamp != C.TIME_UNSET) {
      if (!checkNotNull(extractor).hasReadFirstRtpPacket()) {
        extractor.setFirstTimestamp(timestamp);
      }
    }
  }

  /**
   * Sets the timestamp of an RTP packet to arrive.
   *
   * @param sequenceNumber The sequence number of the RTP packet to arrive. Supply {@link
   *     C#INDEX_UNSET} if its unavailable.
   */
  public void setSequenceNumber(int sequenceNumber) {
    if (!checkNotNull(extractor).hasReadFirstRtpPacket()) {
      extractor.setFirstSequenceNumber(sequenceNumber);
    }
  }

  /** Returns the latest RTP SSRC seen by the loadable, or {@link C#INDEX_UNSET}. */
  public int getLastSsrc() {
    return extractor == null ? C.INDEX_UNSET : extractor.getLastSsrc();
  }

  /** Releases RTP extraction only after the PLAY response has configured every track's timing. */
  public void onPlaybackStarted() {
    playbackTimingReady.open();
  }

  @Override
  public void cancelLoad() {
    loadCancelled = true;
    playbackTimingReady.open();
  }

  @Override
  public void load() throws IOException {
    // Allows to resume loading after canceling load.
    if (loadCancelled) {
      loadCancelled = false;
    }

    try {
      if (dataChannel == null) {
        dataChannel = rtpDataChannelFactory.createAndOpenDataChannel(trackId);
        dataChannel.setRtspDiagnosticsListener(rtspDiagnosticsListener);
        dataChannel.onPlaybackTimingPending();
        String transport = dataChannel.getTransport();
        @RtspTransportMode.Mode
        int transportMode =
            dataChannel.getInterleavedBinaryDataListener() != null
                ? RtspTransportMode.TCP_INTERLEAVED
                : RtspTransportMode.UDP;

        RtpDataChannel finalDataChannel = dataChannel;
        extractorInput =
            new DefaultExtractorInput(
                checkNotNull(dataChannel), /* position= */ 0, /* length= */ C.LENGTH_UNSET);
        extractor =
            new RtpExtractor(
                rtspMediaTrack.payloadFormat,
                trackId,
                transportMode,
                rtspDiagnosticsListener,
                rtcpFeedbackRequester,
                rtcpFeedbackPolicy,
                rtspBacklogRecoveryPolicy,
                rtspPacketDiagnosticsEnabled);
        extractor.init(output);
        playbackTimingReady.close();
        // Publish the initialized extractor before SETUP/PLAY can deliver timestamp configuration.
        playbackThreadHandler.post(
            () -> eventListener.onTransportReady(transport, finalDataChannel));
      }

      // Only the dedicated RTP loader waits. RTSP response delivery and packet producers remain
      // independent; TCP startup buffering is separately bounded by its data channel. A missing PLAY response fails
      // instead of choosing an arbitrary per-track origin. Missing RTP-Info is explicitly released
      // by onPlaybackStarted and retains the existing first-packet fallback.
      if (!loadCancelled) {
        try {
          if (!playbackTimingReady.block(RtspMediaSource.DEFAULT_TIMEOUT_MS) && !loadCancelled) {
            throw new SocketTimeoutException("RTSP PLAY timing not received before RTP startup timeout");
          }
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
          throw new InterruptedIOException("Interrupted waiting for RTSP PLAY timing");
        }
      }

      if (!loadCancelled) {
        checkNotNull(dataChannel).onPlaybackTimingReady();
      }
      while (!loadCancelled) {
        maybeNotifyDataChannelDiscontinuity();
        if (pendingSeekPositionUs != C.TIME_UNSET) {
          checkNotNull(extractor).seek(nextRtpTimestamp, pendingSeekPositionUs);
          pendingSeekPositionUs = C.TIME_UNSET;
        }

        @Extractor.ReadResult
        int readResult =
            checkNotNull(extractor)
                .read(checkNotNull(extractorInput), /* seekPosition= */ new PositionHolder());
        if (readResult == Extractor.RESULT_END_OF_INPUT) {
          // Loading is finished.
          break;
        }
        maybeNotifyDataChannelDiscontinuity();
      }
      // Resets the flag if user cancels loading.
      loadCancelled = false;
    } finally {
      if (dataChannel != null && dataChannel.needsClosingOnLoadCompletion()) {
        DataSourceUtil.closeQuietly(dataChannel);
        dataChannel = null;
      }
    }
  }

  /**
   * Signals when performing an RTSP seek that involves RTSP message exchange.
   *
   * <p>{@link #seekToUs} must be called after the seek is successful.
   */
  public void resetForSeek() {
    checkNotNull(extractor).preSeek();
  }

  /**
   * Sets the correct start position and RTP timestamp after a successful RTSP seek.
   *
   * @param positionUs The position in microseconds from the start, from which the server starts
   *     play.
   * @param nextRtpTimestamp The first RTP packet's timestamp after the seek.
   */
  public void seekToUs(long positionUs, long nextRtpTimestamp) {
    pendingSeekPositionUs = positionUs;
    this.nextRtpTimestamp = nextRtpTimestamp;
  }

  private void maybeNotifyDataChannelDiscontinuity() {
    if (dataChannel == null || extractor == null) {
      return;
    }
    int discontinuityReason = dataChannel.getAndClearPendingDiscontinuityReason();
    if (discontinuityReason != RtcpFeedbackReason.UNKNOWN) {
      extractor.onRtpStreamDiscontinuity(discontinuityReason);
    }
  }
}
